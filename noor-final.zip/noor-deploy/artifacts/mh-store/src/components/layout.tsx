import { Navbar } from "./navbar";
import { Footer } from "./footer";
import { X } from "lucide-react";
import { useState, useEffect } from "react";
import { useI18n } from "@/lib/i18n";
import { ScrollToTop } from "@/components/scroll-to-top";
import { MobileBottomNav } from "@/components/mobile-bottom-nav";
import { NewsletterPopup } from "@/components/newsletter-popup";
import { ComparisonBar } from "@/components/comparison-bar";
import { useSiteSettings } from "@/contexts/site-settings-context";

function AnnouncementBar() {
  const [isVisible, setIsVisible] = useState(true);
  const { language } = useI18n();
  const { settings } = useSiteSettings();
  const data = settings.announcement;

  if (!isVisible || !data.enabled) return null;

  const text = language === "ar" ? data.ar : data.en;

  return (
    <div className="bg-foreground text-background py-2 px-4 relative z-50 flex items-center justify-center text-sm font-medium tracking-wide">
      <div className="container mx-auto text-center pr-8 rtl:pl-8">
        <span>{text}</span>
      </div>
      <button
        onClick={() => setIsVisible(false)}
        className="absolute right-4 rtl:right-auto rtl:left-4 text-background/70 hover:text-background transition-colors"
      >
        <X className="h-4 w-4" />
      </button>
    </div>
  );
}

function WhatsAppButton() {
  const { t } = useI18n();
  const { settings } = useSiteSettings();
  const wa = settings.contact.whatsapp;
  if (!wa) return null;
  return (
    <a
      href={`https://wa.me/${wa}`}
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-6 right-6 z-50 bg-[#25D366] text-white p-4 rounded-full shadow-lg hover:scale-110 transition-transform hover:shadow-xl group"
      title={t("تواصل معنا على واتساب", "Chat with us on WhatsApp")}
    >
      <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="currentColor" viewBox="0 0 16 16">
        <path d="M13.601 2.326A7.854 7.854 0 0 0 7.994 0C3.627 0 .068 3.558.064 7.926c0 1.399.366 2.76 1.057 3.965L0 16l4.204-1.102a7.933 7.933 0 0 0 3.79.965h.004c4.368 0 7.926-3.558 7.93-7.93A7.898 7.898 0 0 0 13.6 2.326zM7.994 14.521a6.573 6.573 0 0 1-3.356-.92l-.24-.144-2.494.654.666-2.433-.156-.251a6.56 6.56 0 0 1-1.007-3.505c0-3.626 2.957-6.584 6.591-6.584a6.56 6.56 0 0 1 4.66 1.931 6.557 6.557 0 0 1 1.928 4.66c-.004 3.639-2.961 6.592-6.592 6.592zm3.615-4.934c-.197-.099-1.17-.578-1.353-.646-.182-.065-.315-.099-.445.099-.133.197-.513.646-.627.775-.114.133-.232.148-.43.05-.197-.1-.836-.308-1.592-.985-.59-.525-.985-1.175-1.103-1.372-.114-.198-.011-.304.088-.403.087-.088.197-.232.296-.346.1-.114.133-.198.198-.33.065-.134.034-.248-.015-.347-.05-.099-.445-1.076-.612-1.47-.16-.389-.323-.335-.445-.34-.114-.007-.247-.007-.38-.007a.729.729 0 0 0-.529.247c-.182.198-.691.677-.691 1.654 0 .977.71 1.916.81 2.049.098.133 1.394 2.132 3.383 2.992.47.205.84.326 1.129.418.475.152.904.129 1.246.08.38-.058 1.171-.48 1.338-.943.164-.464.164-.86.114-.943-.049-.084-.182-.133-.38-.232z"/>
      </svg>
    </a>
  );
}

export function Layout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex flex-col min-h-screen w-full relative selection:bg-primary/20 selection:text-primary">
      <AnnouncementBar />
      <Navbar />
      <main className="flex-1 flex flex-col w-full pb-16 md:pb-0">{children}</main>
      <Footer />
      <WhatsAppButton />
      <ScrollToTop />
      <MobileBottomNav />
      <NewsletterPopup />
      <ComparisonBar />
    </div>
  );
}
