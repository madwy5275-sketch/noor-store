import { db } from "@workspace/db";
import { categoriesTable, productsTable, couponsTable, siteSettingsTable } from "@workspace/db";

async function seed() {
  console.log("\n🌱 Starting full database seed...\n");

  // ============================================================
  // 1. CATEGORIES
  // ============================================================
  console.log("📁 Seeding categories...");
  await db.delete(productsTable);
  await db.delete(categoriesTable);

  const cats = await db.insert(categoriesTable).values([
    { nameAr: "فساتين", nameEn: "Dresses", imageUrl: "https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?w=400" },
    { nameAr: "توبات وبلوزات", nameEn: "Tops", imageUrl: "https://images.unsplash.com/photo-1434389677669-e08b4cac3105?w=400" },
    { nameAr: "بناطيل وتنانير", nameEn: "Pants", imageUrl: "https://images.unsplash.com/photo-1541099649105-f69ad21f3246?w=400" },
    { nameAr: "عبايات", nameEn: "Abayas", imageUrl: "https://images.unsplash.com/photo-1607083206869-4c7672e72a8a?w=400" },
    { nameAr: "إكسسوارات", nameEn: "Accessories", imageUrl: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400" },
    { nameAr: "شنط نسائية", nameEn: "Women's Bags", imageUrl: "https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=400" },
    { nameAr: "ملابس بنات", nameEn: "Kids' Clothes", imageUrl: "https://images.unsplash.com/photo-1519457431-44ccd64a579b?w=400" },
  ]).returning();

  const catMap: Record<string, number> = {};
  cats.forEach(c => { catMap[c.nameEn] = c.id; });
  console.log("✅ Categories created:", Object.keys(catMap).join(", "));

  // ============================================================
  // 2. PRODUCTS
  // ============================================================
  console.log("\n👗 Seeding products...");

  const products = [
    // DRESSES
    {
      nameAr: "فستان ماكسي بوهيمي", nameEn: "Bohemian Maxi Dress",
      descriptionAr: "فستان ماكسي أنيق ومحتشم بتصميم بوهيمي يجمع بين الراحة والأناقة",
      descriptionEn: "Elegant and modest bohemian maxi dress combining comfort and style",
      price: "320", originalPrice: "450",
      imageUrl: "https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?w=600&q=80",
      categoryId: catMap["Dresses"], stock: 20, featured: true,
      sizes: ["S","M","L","XL","XXL"], colors: ["أزرق","أبيض","بيج","زيتي"],
    },
    {
      nameAr: "فستان سواريه أنيق", nameEn: "Elegant Evening Dress",
      descriptionAr: "فستان سواريه راقٍ للمناسبات الخاصة",
      descriptionEn: "Elegant dress for special occasions",
      price: "580", originalPrice: "780",
      imageUrl: "https://images.unsplash.com/photo-1496747611176-843222e1e57c?w=600&q=80",
      categoryId: catMap["Dresses"], stock: 10, featured: true,
      sizes: ["XS","S","M","L"], colors: ["أسود","أحمر","ذهبي"],
    },
    {
      nameAr: "فستان فلوري ربيعي", nameEn: "Floral Spring Dress",
      descriptionAr: "فستان ربيعي بطبعة زهور جميلة ومحتشمة",
      descriptionEn: "Beautiful modest floral spring dress",
      price: "260", originalPrice: "340",
      imageUrl: "https://images.unsplash.com/photo-1572804013309-59a88b7e92f1?w=600&q=80",
      categoryId: catMap["Dresses"], stock: 18, featured: false,
      sizes: ["XS","S","M","L","XL"], colors: ["وردي","أبيض","أزرق"],
    },
    {
      nameAr: "فستان محتشم بأكمام طويلة", nameEn: "Modest Long-Sleeve Dress",
      descriptionAr: "فستان محتشم أنيق بأكمام طويلة مناسب لكل المناسبات",
      descriptionEn: "Modest elegant long-sleeve dress for all occasions",
      price: "340",
      imageUrl: "https://images.unsplash.com/photo-1594938298603-c8148c4dae35?w=600&q=80",
      categoryId: catMap["Dresses"], stock: 25, featured: true,
      sizes: ["S","M","L","XL","XXL","3XL"], colors: ["أسود","كحلي","بيج","ترابي"],
    },
    {
      nameAr: "فستان حفلات شيفون", nameEn: "Chiffon Party Dress",
      descriptionAr: "فستان حفلات من الشيفون الخفيف الفاخر",
      descriptionEn: "Luxury lightweight chiffon party dress",
      price: "490", originalPrice: "620",
      imageUrl: "https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=600&q=80",
      categoryId: catMap["Dresses"], stock: 12, featured: false,
      sizes: ["XS","S","M","L"], colors: ["زهري","ليلكي","فيروزي"],
    },
    // TOPS
    {
      nameAr: "بلوزة شيفون محتشمة", nameEn: "Modest Chiffon Blouse",
      descriptionAr: "بلوزة شيفون محتشمة بأكمام طويلة وأناقة رفيعة",
      descriptionEn: "Modest chiffon blouse with long sleeves and refined elegance",
      price: "145", originalPrice: "200",
      imageUrl: "https://images.unsplash.com/photo-1551163943-3f7254ee3d03?w=600&q=80",
      categoryId: catMap["Tops"], stock: 28, featured: false,
      sizes: ["XS","S","M","L","XL"], colors: ["أبيض","كريمي","وردي فاتح"],
    },
    {
      nameAr: "توب ساتان لامع", nameEn: "Satin Shimmer Top",
      descriptionAr: "توب ساتان أنيق للمناسبات والسهرات",
      descriptionEn: "Elegant satin top for occasions and evenings",
      price: "195",
      imageUrl: "https://images.unsplash.com/photo-1434389677669-e08b4cac3105?w=600&q=80",
      categoryId: catMap["Tops"], stock: 20, featured: false,
      sizes: ["XS","S","M","L","XL"], colors: ["ذهبي","فضي","أسود","خمري"],
    },
    {
      nameAr: "بلوزة كاجوال يومية", nameEn: "Casual Daily Blouse",
      descriptionAr: "بلوزة يومية مريحة ومحتشمة لكل وقت",
      descriptionEn: "Comfortable and modest casual blouse for everyday wear",
      price: "110",
      imageUrl: "https://images.unsplash.com/photo-1503342564933-3e89d851cf8c?w=600&q=80",
      categoryId: catMap["Tops"], stock: 40, featured: false,
      sizes: ["XS","S","M","L","XL","XXL"], colors: ["أبيض","أسود","بيج","وردي"],
    },
    // PANTS
    {
      nameAr: "بنطلون كلاسيك مستقيم", nameEn: "Classic Straight-Cut Pants",
      descriptionAr: "بنطلون كلاسيكي بقصة مستقيمة أنيقة للمرأة العصرية",
      descriptionEn: "Classic straight-cut elegant pants for the modern woman",
      price: "275", originalPrice: "350",
      imageUrl: "https://images.unsplash.com/photo-1541099649105-f69ad21f3246?w=600&q=80",
      categoryId: catMap["Pants"], stock: 22, featured: false,
      sizes: ["XS","S","M","L","XL","XXL"], colors: ["أسود","رمادي","بيج","كحلي"],
    },
    {
      nameAr: "بنطلون واسع بوهيمي", nameEn: "Wide-Leg Boho Pants",
      descriptionAr: "بنطلون واسع محتشم بتصميم عصري ومريح",
      descriptionEn: "Wide-leg modest pants with modern comfortable design",
      price: "240",
      imageUrl: "https://images.unsplash.com/photo-1509631179647-0177331693ae?w=600&q=80",
      categoryId: catMap["Pants"], stock: 17, featured: false,
      sizes: ["S","M","L","XL","XXL"], colors: ["أبيض","أسود","ترابي","بيج"],
    },
    // ABAYAS
    {
      nameAr: "عباية خليجية بتطريز ذهبي", nameEn: "Gulf Abaya with Gold Embroidery",
      descriptionAr: "عباية خليجية فاخرة بتطريز ذهبي يدوي راقٍ",
      descriptionEn: "Luxury Gulf abaya with hand-crafted golden embroidery",
      price: "750", originalPrice: "950",
      imageUrl: "https://images.unsplash.com/photo-1607083206869-4c7672e72a8a?w=600&q=80",
      categoryId: catMap["Abayas"], stock: 8, featured: true,
      sizes: ["S","M","L","XL","XXL","3XL"], colors: ["أسود"],
    },
    {
      nameAr: "عباية كريب مودرن", nameEn: "Modern Crepe Abaya",
      descriptionAr: "عباية كريب سادة بقصة عصرية أنيقة",
      descriptionEn: "Plain crepe abaya with elegant modern cut",
      price: "420",
      imageUrl: "https://images.unsplash.com/photo-1583391733956-6c78276477e2?w=600&q=80",
      categoryId: catMap["Abayas"], stock: 18, featured: true,
      sizes: ["S","M","L","XL","XXL","3XL"], colors: ["أسود","كحلي","رمادي","بنفسجي غامق"],
    },
    {
      nameAr: "عباية جورجيت مطرزة", nameEn: "Embroidered Georgette Abaya",
      descriptionAr: "عباية جورجيت فاخرة بتطريز حريري جميل",
      descriptionEn: "Luxury georgette abaya with beautiful silk embroidery",
      price: "580", originalPrice: "720",
      imageUrl: "https://images.unsplash.com/photo-1551489186-cf8726f514f8?w=600&q=80",
      categoryId: catMap["Abayas"], stock: 10, featured: false,
      sizes: ["S","M","L","XL","XXL"], colors: ["أسود","عنابي","رمادي"],
    },
    // BAGS
    {
      nameAr: "شنطة يد جلد فاخرة", nameEn: "Luxury Leather Handbag",
      descriptionAr: "شنطة يد من الجلد الطبيعي بتصميم كلاسيكي فاخر",
      descriptionEn: "Natural leather handbag with classic luxury design",
      price: "890", originalPrice: "1200",
      imageUrl: "https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=600&q=80",
      categoryId: catMap["Women's Bags"], stock: 7, featured: true,
      sizes: ["واحد مقاس"], colors: ["بني","أسود","كاميل"],
    },
    {
      nameAr: "شنطة كتف أنيقة", nameEn: "Elegant Shoulder Bag",
      descriptionAr: "شنطة كتف أنيقة بسعة واسعة ومواد عالية الجودة",
      descriptionEn: "Elegant shoulder bag with spacious capacity and quality materials",
      price: "520", originalPrice: "680",
      imageUrl: "https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=600&q=80",
      categoryId: catMap["Women's Bags"], stock: 12, featured: true,
      sizes: ["واحد مقاس"], colors: ["بيج","أسود","وردي","بني"],
    },
    {
      nameAr: "شنطة كروس بودي صغيرة", nameEn: "Mini Crossbody Bag",
      descriptionAr: "شنطة كروس بودي صغيرة أنيقة وعملية",
      descriptionEn: "Stylish and practical mini crossbody bag",
      price: "310",
      imageUrl: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=600&q=80",
      categoryId: catMap["Women's Bags"], stock: 20, featured: false,
      sizes: ["واحد مقاس"], colors: ["أسود","بني","خمري","بيج"],
    },
    {
      nameAr: "شنطة توت كبيرة", nameEn: "Large Tote Bag",
      descriptionAr: "شنطة توت كبيرة مثالية للعمل والخروجات اليومية",
      descriptionEn: "Large tote bag perfect for work and daily outings",
      price: "440", originalPrice: "580",
      imageUrl: "https://images.unsplash.com/photo-1566150905458-1bf1fc113f0d?w=600&q=80",
      categoryId: catMap["Women's Bags"], stock: 14, featured: false,
      sizes: ["واحد مقاس"], colors: ["كاميل","أسود","بيج","وردي"],
    },
    {
      nameAr: "كلتش سهرة لامع", nameEn: "Glitter Evening Clutch",
      descriptionAr: "كلتش سهرة لامع للمناسبات والحفلات الخاصة",
      descriptionEn: "Glittery evening clutch for special events and parties",
      price: "245",
      imageUrl: "https://images.unsplash.com/photo-1547949003-9792a18a2601?w=600&q=80",
      categoryId: catMap["Women's Bags"], stock: 25, featured: false,
      sizes: ["واحد مقاس"], colors: ["ذهبي","فضي","أسود","وردي"],
    },
    // KIDS
    {
      nameAr: "فستان بنات ورد جميل", nameEn: "Floral Girls' Dress",
      descriptionAr: "فستان بنات جميل بطبعة ورود ملونة للمناسبات والعيد",
      descriptionEn: "Beautiful floral girls' dress for occasions and Eid",
      price: "195", originalPrice: "260",
      imageUrl: "https://images.unsplash.com/photo-1518831959646-742c3a14ebf7?w=600&q=80",
      categoryId: catMap["Kids' Clothes"], stock: 22, featured: true,
      sizes: ["2سنة","4سنة","6سنة","8سنة","10سنة"], colors: ["وردي","أصفر","أزرق فاتح"],
    },
    {
      nameAr: "طقم بنات كاجوال", nameEn: "Girls' Casual Set",
      descriptionAr: "طقم بنات كاجوال مريح وأنيق للمدرسة والخروجات",
      descriptionEn: "Comfortable and stylish girls' casual set for school and outings",
      price: "185",
      imageUrl: "https://images.unsplash.com/photo-1622290291468-a28f7a7dc6a8?w=600&q=80",
      categoryId: catMap["Kids' Clothes"], stock: 30, featured: false,
      sizes: ["4سنة","6سنة","8سنة","10سنة","12سنة"], colors: ["زهري","أزرق","أخضر","بيج"],
    },
    {
      nameAr: "فستان عيد فاخر للبنات", nameEn: "Luxury Girls' Eid Dress",
      descriptionAr: "فستان عيد فاخر للبنات بتصميم أميرات ساحر",
      descriptionEn: "Luxury princess-design Eid dress for girls",
      price: "290", originalPrice: "380",
      imageUrl: "https://images.unsplash.com/photo-1519457431-44ccd64a579b?w=600&q=80",
      categoryId: catMap["Kids' Clothes"], stock: 14, featured: true,
      sizes: ["2سنة","4سنة","6سنة","8سنة","10سنة"], colors: ["وردي","أبيض","ذهبي","ليلكي"],
    },
    {
      nameAr: "بيجاما بنات قطن ناعم", nameEn: "Soft Cotton Girls' Pajama",
      descriptionAr: "بيجاما بنات من القطن الناعم بتصاميم مبهجة وألوان زاهية",
      descriptionEn: "Soft cotton girls' pajama with fun and colorful designs",
      price: "150", originalPrice: "195",
      imageUrl: "https://images.unsplash.com/photo-1514996937319-344454492b37?w=600&q=80",
      categoryId: catMap["Kids' Clothes"], stock: 35, featured: false,
      sizes: ["2سنة","4سنة","6سنة","8سنة","10سنة","12سنة"], colors: ["وردي","أزرق فاتح","أصفر","أخضر"],
    },
    {
      nameAr: "طقم مدرسي بنات", nameEn: "Girls' School Outfit",
      descriptionAr: "طقم مدرسي أنيق ومريح للبنات بألوان راقية",
      descriptionEn: "Elegant and comfortable girls' school outfit in refined colors",
      price: "210",
      imageUrl: "https://images.unsplash.com/photo-1519278409-1f56ab241e83?w=600&q=80",
      categoryId: catMap["Kids' Clothes"], stock: 25, featured: false,
      sizes: ["4سنة","6سنة","8سنة","10سنة","12سنة","14سنة"], colors: ["كحلي","أسود","رمادي"],
    },
    {
      nameAr: "فستان طرحة للبنات", nameEn: "Girls' Hijab Dress Set",
      descriptionAr: "فستان مع طرحة للبنات محتشم وأنيق للمناسبات",
      descriptionEn: "Modest and elegant girls' dress with hijab for occasions",
      price: "245", originalPrice: "310",
      imageUrl: "https://images.unsplash.com/photo-1505944270255-72b8c68c6a70?w=600&q=80",
      categoryId: catMap["Kids' Clothes"], stock: 18, featured: true,
      sizes: ["4سنة","6سنة","8سنة","10سنة","12سنة"], colors: ["وردي","أبيض","بنفسجي"],
    },
    // ACCESSORIES
    {
      nameAr: "ساعة نسائية أنيقة", nameEn: "Elegant Women's Watch",
      descriptionAr: "ساعة نسائية أنيقة بسوار معدني لامع",
      descriptionEn: "Elegant women's watch with shiny metal strap",
      price: "680", originalPrice: "880",
      imageUrl: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=600&q=80",
      categoryId: catMap["Accessories"], stock: 8, featured: true,
      sizes: ["واحد مقاس"], colors: ["ذهبي","فضي","روزغولد"],
    },
    {
      nameAr: "نظارة شمسية نسائية", nameEn: "Women's Fashion Sunglasses",
      descriptionAr: "نظارة شمسية نسائية بتصميم كلاسيكي أنيق",
      descriptionEn: "Women's sunglasses with classic elegant design",
      price: "280",
      imageUrl: "https://images.unsplash.com/photo-1508296695146-257a814070b4?w=600&q=80",
      categoryId: catMap["Accessories"], stock: 20, featured: false,
      sizes: ["واحد مقاس"], colors: ["أسود","ذهبي","بني","فضي"],
    },
    {
      nameAr: "إيشارب حرير راقٍ", nameEn: "Luxury Silk Scarf",
      descriptionAr: "إيشارب حرير فاخر بألوان زاهية ومتعددة",
      descriptionEn: "Luxury silk scarf in vibrant multicolors",
      price: "240", originalPrice: "320",
      imageUrl: "https://images.unsplash.com/photo-1591369822096-ffd140ec948f?w=600&q=80",
      categoryId: catMap["Accessories"], stock: 25, featured: false,
      sizes: ["واحد مقاس"], colors: ["متعدد الألوان"],
    },
    {
      nameAr: "خاتم ذهبي أنيق", nameEn: "Elegant Gold Ring",
      descriptionAr: "خاتم ذهبي اللون بتصميم بسيط وأنيق",
      descriptionEn: "Gold-colored ring with simple and elegant design",
      price: "185",
      imageUrl: "https://images.unsplash.com/photo-1605100804763-247f67b3557e?w=600&q=80",
      categoryId: catMap["Accessories"], stock: 30, featured: false,
      sizes: ["واحد مقاس"], colors: ["ذهبي","فضي","روزغولد"],
    },
  ];

  let added = 0;
  for (const p of products) {
    if (!p.categoryId) { console.warn("⚠️  Skipping (no category):", p.nameEn); continue; }
    await db.insert(productsTable).values({
      nameAr: p.nameAr, nameEn: p.nameEn,
      descriptionAr: p.descriptionAr, descriptionEn: p.descriptionEn,
      price: p.price, originalPrice: p.originalPrice ?? null,
      imageUrl: p.imageUrl, images: [],
      categoryId: p.categoryId, stock: p.stock,
      featured: p.featured, sizes: p.sizes, colors: p.colors,
    });
    added++;
    process.stdout.write(`✓ ${p.nameEn}\n`);
  }
  console.log(`\n✅ ${added} products added.`);

  // ============================================================
  // 3. COUPONS
  // ============================================================
  console.log("\n🎟️  Seeding coupons...");
  await db.delete(couponsTable);
  await db.insert(couponsTable).values([
    { code: "EID25", discountPercentage: 25, active: true, description: "خصم العيد 25%" },
    { code: "NOOR10", discountPercentage: 10, active: true, description: "خصم نور 10%" },
    { code: "VIP30", discountPercentage: 30, active: false, description: "خصم VIP 30% - غير نشط" },
    { code: "WELCOME15", discountPercentage: 15, active: true, description: "خصم ترحيب 15%" },
  ]);
  console.log("✅ Coupons: EID25, NOOR10, VIP30, WELCOME15");

  // ============================================================
  // 4. SITE SETTINGS
  // ============================================================
  console.log("\n⚙️  Seeding site settings...");

  const settings = [
    {
      key: "brand",
      value: {
        nameAr: "متجر نور",
        nameEn: "Noor Store",
        taglineAr: "أناقة محتشمة لكل مناسبة",
        taglineEn: "Modest elegance for every occasion",
        logoUrl: "",
        primaryColor: "#c084fc",
        whatsapp: "01552221286",
        phone: "01552221286",
        email: "info@noorstore.com",
      },
    },
    {
      key: "contact",
      value: {
        phone: "01552221286",
        whatsapp: "01552221286",
        email: "info@noorstore.com",
        address: "القاهرة، مصر",
        facebook: "https://facebook.com/noorstore",
        instagram: "https://instagram.com/noorstore",
        tiktok: "https://tiktok.com/@noorstore",
      },
    },
    {
      key: "announcement",
      value: {
        enabled: true,
        ar: "🎉 الشحن مجاناً على الطلبات فوق 500 جنيه | اتصل بنا: 01552221286",
        en: "🎉 Free shipping on orders over 500 EGP | Call us: 01552221286",
      },
    },
    {
      key: "hero",
      value: {
        slides: [
          {
            id: "1",
            titleAr: "أناقة محتشمة",
            titleEn: "Modest Elegance",
            subtitleAr: "تسوقي أحدث التصاميم العصرية",
            subtitleEn: "Shop the latest modern designs",
            image: "https://images.unsplash.com/photo-1483985988355-763728e1935b?w=1400&q=80",
            ctaAr: "تسوقي الآن",
            ctaEn: "Shop Now",
            ctaLink: "/products",
          },
          {
            id: "2",
            titleAr: "عبايات فاخرة",
            titleEn: "Luxury Abayas",
            subtitleAr: "تشكيلة واسعة من العبايات الراقية",
            subtitleEn: "Wide collection of elegant abayas",
            image: "https://images.unsplash.com/photo-1607083206869-4c7672e72a8a?w=1400&q=80",
            ctaAr: "اكتشفي العبايات",
            ctaEn: "Explore Abayas",
            ctaLink: "/abayas",
          },
          {
            id: "3",
            titleAr: "شنط نسائية",
            titleEn: "Women's Bags",
            subtitleAr: "أجمل الشنط والإكسسوارات",
            subtitleEn: "The most beautiful bags and accessories",
            image: "https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=1400&q=80",
            ctaAr: "تسوقي الشنط",
            ctaEn: "Shop Bags",
            ctaLink: "/products?category=bags",
          },
        ],
      },
    },
    {
      key: "payment",
      value: {
        cod: { enabled: true, nameAr: "الدفع عند الاستلام", nameEn: "Cash on Delivery", fee: 0 },
        vodafone_cash: { enabled: true, nameAr: "فودافون كاش", nameEn: "Vodafone Cash", number: "01552221286", fee: 0 },
        instapay: { enabled: true, nameAr: "إنستاباي", nameEn: "InstaPay", number: "01552221286", fee: 0 },
        fawry: { enabled: true, nameAr: "فوري", nameEn: "Fawry", fee: 5 },
        card: { enabled: false, nameAr: "بطاقة بنكية", nameEn: "Credit/Debit Card", fee: 0 },
      },
    },
    {
      key: "shipping",
      value: {
        freeThreshold: 500,
        defaultCost: 60,
        cities: [
          { nameAr: "القاهرة", nameEn: "Cairo", cost: 40 },
          { nameAr: "الجيزة", nameEn: "Giza", cost: 40 },
          { nameAr: "الإسكندرية", nameEn: "Alexandria", cost: 60 },
          { nameAr: "المنصورة", nameEn: "Mansoura", cost: 65 },
          { nameAr: "أسوان", nameEn: "Aswan", cost: 80 },
        ],
      },
    },
    {
      key: "sections",
      value: {
        featuredProducts: { enabled: true, titleAr: "منتجات مميزة", titleEn: "Featured Products", limit: 8 },
        newArrivals: { enabled: true, titleAr: "وصل حديثاً", titleEn: "New Arrivals", limit: 8 },
        abayas: { enabled: true, titleAr: "عبايات", titleEn: "Abayas", limit: 6 },
        bags: { enabled: true, titleAr: "شنط نسائية", titleEn: "Women's Bags", limit: 6 },
      },
    },
    {
      key: "sale",
      value: {
        enabled: true,
        endDate: "2026-12-31T23:59:59",
        discount: 30,
        titleAr: "تخفيضات العيد — خصم يصل إلى ٣٠٪",
        titleEn: "Eid Sale — Up to 30% Off",
      },
    },
  ];

  for (const s of settings) {
    await db
      .insert(siteSettingsTable)
      .values({ key: s.key, value: s.value, updatedAt: new Date() })
      .onConflictDoUpdate({
        target: siteSettingsTable.key,
        set: { value: s.value, updatedAt: new Date() },
      });
    console.log(`✓ Setting: ${s.key}`);
  }

  console.log("\n🎉 Database fully seeded!");
  console.log("=====================================");
  console.log(`  ✅ ${cats.length} categories`);
  console.log(`  ✅ ${added} products`);
  console.log(`  ✅ 4 coupon codes`);
  console.log(`  ✅ ${settings.length} site settings`);
  console.log("=====================================");
  console.log("\nAdmin login: /seller/login");
  console.log("Username: admin | Password: MH@Store2024\n");
  process.exit(0);
}

seed().catch(e => { console.error("❌ Seed failed:", e); process.exit(1); });
